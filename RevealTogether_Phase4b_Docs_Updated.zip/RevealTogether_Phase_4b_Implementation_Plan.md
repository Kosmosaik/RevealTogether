# RevealTogether - Phase 4b Implementation Plan

**Branch:** `phase-4b-qol`  
**Purpose:** Stabilize, clean up, and improve the current Phase 4 foundation before continuing into Phase 5.  
**Source of truth:** Latest audited project zip only. Older zips and memory are not trusted for implementation decisions.

## Current Phase 4b status (2026-04-28)

Phase 4b is in progress. The original cleanup/stability work has mostly been completed or intentionally deferred, and the branch expanded to include a large-board performance/loading addendum.

Major implemented Phase 4b results:

- Config-driven default tile HP.
- Config-driven board view/world/rendering/loading UI values.
- Reveal images moved into `assets/reveal_images/`.
- Stronger startup validation for authored tile visual scenes.
- Chunk state population during board generation.
- Faster local chunk-seed board generation.
- MultiMesh large-board rendering.
- Incremental MultiMesh tile deltas.
- Streamed initial join snapshots.
- Compact streamed snapshot payloads.
- Hybrid capped detail overlay for large boards.
- Progressive client-side visual build.
- Loading/progress UI.

Deferred or skipped:

- Broad palette/lighting/shadow art pass was reverted for now because it did not look good enough.
- Full script-folder reorganization is not being forced right now.
- Optional board geometry helper is deferred.
- Final distant-board visual polish is still open.

## 1. Phase 4b Goals

Phase 4b is a quality, stability, maintainability, presentation, and large-board viability pass. It should not introduce major new gameplay systems unless they directly support stability, clarity, performance, loading, or visual presentation.

The main goals are:

1. Improve project stability before Phase 5.
2. Remove or fix config drift where config values exist but are not used.
3. Improve visual presentation where changes are clearly beneficial.
4. Add stronger validation around authored visual content.
5. Clean up file organization where it is safe and valuable.
6. Make large boards viable without hiding most of the board.
7. Keep the project data-driven, modular, and easy to tune.

## 2. Non-goals

Do not use Phase 4b for:

- inventory implementation,
- item definitions,
- Tool/Charm systems,
- crafting,
- monetization,
- production art pipelines,
- large role asymmetry,
- major gameplay expansion unrelated to stability/performance/presentation.

## 3. Implementation Rules

- Do not infer names.
- Do not guess methods, properties, signals, node paths, resource fields, Dictionary keys, or return values.
- Check dependent scripts before touching a script.
- Keep runtime truth separate from presentation/debug/loading UI.
- Keep gameplay content and tuning in defs/resources/config.
- Prefer reusable systems and explicit responsibilities over shortcuts.
- Provide exact replacement functions/scripts when implementing.
- Use the latest provided zip as the only source of current truth.

## 4. Phase 4b Work Order and Status

### 4b.1 - Baseline cleanup

Status: Mostly complete.

Completed/covered:

- Branch exists as `phase-4b-qol`.
- Current Git state contains intended Phase 4b changes waiting for commit.
- Documentation is being refreshed to match current state.

Still useful before final commit:

- Review `git status --short`.
- Confirm no unintended `.godot` cache files or temporary files are staged.
- Commit only intended source/assets/docs.

### 4b.2 - Config correctness and data-driven cleanup

Status: Implemented for current chosen scope.

Completed:

- Default tile HP is config-driven through `[board_actions] default_tile_hp`.
- Board view values are configurable under `[board_view]`.
- Rendering/camera/world/loading UI values are configurable under appropriate config sections.
- `MapPresetDef.family_region_seed_search_radius_chunks` is implemented and used by board generation.

Deferred:

- Additional config cleanup should be handled only when a concrete unused/drifted value is found.

### 4b.3 - Visual and lighting improvement pass

Status: Partially implemented, broad art changes deferred.

Completed:

- Environment/background/lighting/shadow/rendering values have config entries.
- Viewport AA/rendering settings are configurable.

Deferred:

- The attempted broad color/palette/shadow look was reverted because it did not look good.
- Future visual work should be smaller, targeted, and tested in-game before committing.

### 4b.4 - Startup and content validation hardening

Status: Implemented for tile visual scenes.

Completed:

- Client-side startup validation checks `TileVariantDef.visual_scene`.
- Visual scene root must be `BoardTileVisual`.
- Important `BoardTileVisual` node paths are validated.
- Dedicated server mode skips visual scene instantiation checks.

### 4b.5 - Asset and file organization cleanup

Status: Partially implemented.

Completed:

- Reveal images have been moved from the project root into `assets/reveal_images/`.
- Map preset references were updated to use the new asset paths.

Deferred:

- Full script relocation into a single `/scripts` folder is not recommended right now. The current domain-based structure is acceptable and avoids unnecessary UID/reference churn.
- Inconsistent content ID cleanup should only happen with careful reference checks.

### 4b.6 - Optional board geometry helper

Status: Deferred.

This can wait until there is repeated board geometry math duplication or a concrete bug caused by inconsistent calculations.

### 4b.7 - Large-board performance foundation

Status: Implemented.

Detailed plan lives in `RevealTogether_Phase_4b_Large_Board_Performance_Plan.md`.

Implemented:

- chunk state population,
- local chunk-seed search,
- MultiMesh board renderer path,
- incremental MultiMesh tile updates,
- streamed join snapshots,
- compact streamed snapshot payloads,
- hybrid detail overlay,
- progressive visual build,
- loading/progress UI.

### 4b.8 - Large-board visual richness/readability

Status: Next recommended topic.

Goal:

Improve large-board visual richness without returning to one full authored scene per tile.

Candidate approaches:

- per-family/per-variant MultiMesh groups,
- subtle height or scale variation,
- chunk/region tinting,
- clearer state/family material strategy,
- subtle distant grid/region overlays,
- better authored detail priorities.

## 5. Suggested commit breakdown

Recommended single commit for the current state:

```text
Improve Phase 4b large-board loading and presentation foundation
```

Suggested commit body:

```text
- Add streamed and compact streamed join board snapshots
- Add progressive MultiMesh board visual build
- Add loading/progress UI for board receive/build stages
- Add capped large-board detail overlay
- Improve large-board generation and rendering performance
- Move reveal images into assets/reveal_images
- Update project documentation for current Phase 4b state
```

If you prefer smaller commits, use:

1. `Move reveal images and update content validation`
2. `Add large-board snapshot streaming and compact payloads`
3. `Add progressive large-board rendering and loading UI`
4. `Update Phase 4b documentation`

## 6. Manual test checklist before commit

- Dedicated server starts.
- Client connects and joins.
- 64 x 64 map loads.
- 224 x 224 or larger map loads.
- Intended stress-test board loads.
- Loading/progress UI shows during snapshot receive/build.
- Loading/progress UI hides when ready.
- Clicking/revealing does not freeze noticeably.
- Detail overlay does not flicker against MultiMesh covers.
- Player movement and camera remain smooth after board load.
- Startup validation has no unexpected errors.

## 7. Recommended next step

Commit/push the current working state after verifying the manual checklist. Then either:

1. finish Phase 4b with large-board visual richness/readability, or
2. intentionally pause Phase 4b and start Phase 5 Tool/Charm/inventory scaffolding.
