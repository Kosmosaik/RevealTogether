# RevealTogether Phase 4b Addendum: Large Board Performance Plan

## Purpose

This addendum covers the large-board performance and loading work discovered while testing boards larger than the original 64 x 64 sandbox size.

The current large-board direction is:

- keep the full board visible,
- avoid classic proximity chunk loading that hides distant tiles,
- use chunking for batching, indexing, streaming, and dirty-state organization,
- use cheap full-board rendering for scale,
- layer detailed visuals only where they matter,
- show clear loading/progress feedback during long joins/builds.

## Current large-board state (2026-04-28)

Implemented and working in the current repo:

- chunk state is populated during board generation,
- board generation uses local chunk-seed search instead of every tile checking every chunk seed,
- large boards render through a full-board MultiMesh path,
- tile changes update MultiMesh instances incrementally,
- large initial board snapshots are streamed in chunks,
- compact streamed snapshot payloads reduce large-board join payload cost,
- large boards build client visuals progressively across frames,
- loading/progress UI reports snapshot receive and visual build progress,
- large boards can use capped authored detail visuals near focus/hover/recently changed tiles.

The remaining large-board work is mostly presentation/readability tuning, not fundamental loading viability.

## Findings that drove this plan

### Server board generation cost

The original procedural tile-family assignment compared every tile against every chunk seed. Large boards made that too expensive. The fix was to search only nearby chunk seeds using a configurable radius.

### Client detailed scene cost

Creating one full tile visual scene per tile does not scale to large boards. Large boards need a cheap full-board renderer and a capped detail overlay.

### Full-board snapshot payload size

Sending one huge reliable RPC with every tile dictionary failed around the earlier 224 x 224 to 240 x 240 test range. The fix was streamed initial snapshots, then compact streamed snapshots.

### Initial client visual build cost

Even after streaming, the client still needs to process and display many tiles. The fix was progressive visual build plus loading/progress UI.

### Runtime delta performance

Full-board rebuilds on tile deltas caused click/remove freezes. Incremental MultiMesh tile updates fixed that issue.

## Design goals

- Keep the whole board visible.
- Do not rely on hiding distant chunks as the primary performance solution.
- Keep authoritative runtime truth in `BoardState`, `TileRecord`, `ChunkState`, and related runtime services.
- Keep presentation state in board view / renderer nodes.
- Keep tuning in config/resources instead of hardcoding gameplay values.
- Use chunking for batching, indexing, streaming, dirty tracking, and future network optimization.
- Preserve authored tile visual scenes for close-range detail, hover/selection feedback, and small boards.
- Make large boards load progressively and predictably instead of freezing or silently failing.

## Implementation order and status

### Step 1 - Populate chunk state during board generation

Status: Implemented.

Each `TileRecord` is assigned to a real `ChunkState` during board generation. This gives chunk metadata real runtime value and prepares the board for chunk-level streaming/dirty tracking/diagnostics later.

### Step 2 - Replace all-seed tile-family search with local chunk-seed search

Status: Implemented.

`MapPresetDef.family_region_seed_search_radius_chunks` controls how far each tile searches for nearby region seeds. This prevents large boards from doing every-tile-against-every-seed work.

### Step 3 - Add a baseline MultiMesh board renderer path

Status: Implemented.

Large boards use `MultiMeshInstance3D` groups for broad tile states instead of instantiating one full scene per tile.

### Step 4 - Make large-board tile deltas incremental

Status: Implemented.

Tile state changes update affected MultiMesh instances rather than rebuilding the full board presentation.

### Step 5 - Stream the initial join board snapshot

Status: Implemented.

Large board joins can send a snapshot header, multiple board snapshot chunks, and a completion event instead of one giant reliable RPC.

### Step 6 - Compact streamed board snapshots

Status: Implemented.

The server can send compact streamed tile data using palettes/arrays/flags. The client expands compact chunk data back into normal tile snapshot dictionaries before applying the joined-match flow.

Relevant config:

- `replication.join_snapshot_stream_compact_enabled`
- `replication.join_snapshot_stream_tile_threshold`
- `replication.join_snapshot_stream_batch_size`

### Step 7 - Add hybrid detailed visuals for large boards

Status: Implemented.

Large boards keep the cheap full-board MultiMesh layer and add authored `BoardTileVisual` scenes only for a capped detail set.

Current detail candidates include:

- nearby/focus tiles,
- hovered tile,
- recently changed/important tiles.

Relevant config:

- `board_view.large_board_detail_overlay_enabled`
- `board_view.detail_overlay_radius_tiles`
- `board_view.detail_overlay_max_tiles`
- `board_view.detail_overlay_changed_tile_hold_ms`
- `board_view.detail_overlay_refresh_interval_ms`

### Step 8 - Add progressive client-side board visual build

Status: Implemented.

Large board MultiMesh data can be built across frames instead of all at once.

Relevant config:

- `board_view.progressive_multimesh_build_enabled`
- `board_view.progressive_multimesh_build_threshold`
- `board_view.progressive_multimesh_build_batch_size`
- `board_view.progressive_multimesh_build_log_interval_tiles`

### Step 9 - Add explicit large-board loading/progress feedback

Status: Implemented.

`LoadingProgressOverlay` displays progress during:

- receiving streamed board snapshot chunks,
- building board visuals progressively.

Relevant config:

- `loading_progress_ui.enabled`
- `loading_progress_ui.canvas_layer`
- `loading_progress_ui.minimum_panel_width`
- `loading_progress_ui.overlay_color`
- `loading_progress_ui.panel_color`
- `loading_progress_ui.title_text_color`
- `loading_progress_ui.detail_text_color`
- `loading_progress_ui.title_font_size`
- `loading_progress_ui.detail_font_size`
- `loading_progress_ui.percent_font_size`

### Step 10 - Improve large-board visual richness without per-tile scenes everywhere

Status: Next recommended step.

The current large-board renderer is viable, but distant board areas can still look too simple. The next work should improve readability and richness without returning to full per-tile scene instantiation.

Good candidates:

- per-family or per-variant MultiMesh groups,
- subtle height/scale variation in the MultiMesh layer,
- chunk/region tinting,
- state/family material strategy,
- subtle grid or region overlays,
- LOD meshes for common tile families,
- better distant/near visual separation.

Expected effect:

- distant board areas feel less flat,
- family/region identity becomes more readable,
- the board stays performant at large sizes,
- authored detail still appears near the player through the hybrid detail layer.

## Current suggested tuning mindset

### Snapshot stream batch size

`join_snapshot_stream_batch_size` controls how many tiles are packed into each network snapshot chunk. Higher values mean fewer chunks and less per-chunk overhead, but each chunk is larger.

### Stream threshold

`join_snapshot_stream_tile_threshold` controls when the streamed path is used. It should stay low enough that risky one-payload joins are avoided.

### Progressive visual build batch size

`progressive_multimesh_build_batch_size` controls how many tiles are processed per frame during visual build. Higher values finish faster but can create bigger frame spikes. Lower values feel smoother but take longer.

### Detail overlay radius/max

`detail_overlay_radius_tiles` defines the nearby candidate area. `detail_overlay_max_tiles` caps how many authored detailed visual scenes can exist at once. The cap is the final safety limit.

## Manual test checklist

- 64 x 64 board joins and renders correctly.
- 224 x 224 or larger board joins and renders correctly.
- Intended stress-test board joins without silent failure.
- Loading/progress UI appears during long loads and hides when ready.
- Board visual build progresses without a long client freeze.
- Clicking/revealing a tile does not freeze the full board.
- Detail overlay does not flicker against the MultiMesh layer.
- Distant board remains visible.
- Player movement and camera stay smooth after loading.

## Completion condition for this addendum

This addendum can be considered functionally complete when Step 10 is either implemented or intentionally deferred with documented visual goals. The technical large-board foundation is already in place.
